// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
	apiKey: "AIzaSyC7GdzpzryFYOtgJIfKYrDyINzo8SiMNbw",
    authDomain: "androidpam-62a8c.firebaseapp.com",
    projectId: "androidpam-62a8c",
    storageBucket: "androidpam-62a8c.appspot.com",
    messagingSenderId: "517447229875",
    appId: "1:517447229875:web:062044390a8ffdadecabc6",
    measurementId: "G-RRC04D7YKP"
 };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();